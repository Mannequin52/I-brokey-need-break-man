﻿namespace Biblioteka_AS
{
    partial class Korisnik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.imekorisniktxt = new System.Windows.Forms.TextBox();
            this.prezimekorisniktxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dobkorisniktxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.brojteltxt = new System.Windows.Forms.TextBox();
            this.emailtxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.oibkorisniktxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.adresakorisniktxt = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime:";
            // 
            // imekorisniktxt
            // 
            this.imekorisniktxt.Location = new System.Drawing.Point(42, 39);
            this.imekorisniktxt.Name = "imekorisniktxt";
            this.imekorisniktxt.Size = new System.Drawing.Size(100, 20);
            this.imekorisniktxt.TabIndex = 1;
            this.imekorisniktxt.TextChanged += new System.EventHandler(this.imekorisniktxt_TextChanged);
            // 
            // prezimekorisniktxt
            // 
            this.prezimekorisniktxt.Location = new System.Drawing.Point(163, 39);
            this.prezimekorisniktxt.Name = "prezimekorisniktxt";
            this.prezimekorisniktxt.Size = new System.Drawing.Size(100, 20);
            this.prezimekorisniktxt.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Godina rođenja: (DD-MM-YYYY)";
            // 
            // dobkorisniktxt
            // 
            this.dobkorisniktxt.Location = new System.Drawing.Point(42, 95);
            this.dobkorisniktxt.Name = "dobkorisniktxt";
            this.dobkorisniktxt.Size = new System.Drawing.Size(100, 20);
            this.dobkorisniktxt.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Broj telefona:";
            // 
            // brojteltxt
            // 
            this.brojteltxt.Location = new System.Drawing.Point(42, 150);
            this.brojteltxt.Name = "brojteltxt";
            this.brojteltxt.Size = new System.Drawing.Size(100, 20);
            this.brojteltxt.TabIndex = 6;
            // 
            // emailtxt
            // 
            this.emailtxt.Location = new System.Drawing.Point(163, 150);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(100, 20);
            this.emailtxt.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(160, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "E-mail:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 251);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Adresa:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(42, 347);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 36);
            this.button1.TabIndex = 11;
            this.button1.Text = "Unesi";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(163, 347);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 36);
            this.button2.TabIndex = 12;
            this.button2.Text = "Odustani";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // oibkorisniktxt
            // 
            this.oibkorisniktxt.Location = new System.Drawing.Point(42, 211);
            this.oibkorisniktxt.Name = "oibkorisniktxt";
            this.oibkorisniktxt.Size = new System.Drawing.Size(100, 20);
            this.oibkorisniktxt.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "OIB:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(160, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Prezime:";
            // 
            // adresakorisniktxt
            // 
            this.adresakorisniktxt.Location = new System.Drawing.Point(42, 267);
            this.adresakorisniktxt.Name = "adresakorisniktxt";
            this.adresakorisniktxt.Size = new System.Drawing.Size(221, 64);
            this.adresakorisniktxt.TabIndex = 16;
            this.adresakorisniktxt.Text = "";
            // 
            // Korisnik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(305, 421);
            this.Controls.Add(this.adresakorisniktxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.oibkorisniktxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.emailtxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.brojteltxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dobkorisniktxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.prezimekorisniktxt);
            this.Controls.Add(this.imekorisniktxt);
            this.Controls.Add(this.label1);
            this.Name = "Korisnik";
            this.Text = "Korisnik";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox imekorisniktxt;
        private System.Windows.Forms.TextBox prezimekorisniktxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox dobkorisniktxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox brojteltxt;
        private System.Windows.Forms.TextBox emailtxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox oibkorisniktxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox adresakorisniktxt;
    }
}